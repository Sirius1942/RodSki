# 需求文档

RodSki 框架的需求管理文档目录。

## 文档列表

| 文档 | 说明 |
|------|------|
| [RODSKI_REQUIREMENTS.md](RODSKI_REQUIREMENTS.md) | RodSki 需求总览 — 关键字驱动框架、多端覆盖、CLI/GUI/CI 集成 |

### 历史归档

| 文档 | 说明 |
|------|------|
| [archive/RODSKI_REQUIREMENTS_HISTORY_2026-03-20.md](archive/RODSKI_REQUIREMENTS_HISTORY_2026-03-20.md) | 需求与文档梳理纪要（2026-03-20） |

---

**关联规范**: [../../rodski/docs/CORE_DESIGN_CONSTRAINTS.md](../../rodski/docs/CORE_DESIGN_CONSTRAINTS.md)
