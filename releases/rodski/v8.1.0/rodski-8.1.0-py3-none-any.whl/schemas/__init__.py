"""RodSki XML schema package."""
